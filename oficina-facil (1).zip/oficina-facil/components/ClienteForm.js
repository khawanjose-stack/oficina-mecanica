"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/lib/AuthContext";
import { supabase } from "@/lib/supabaseClient";
import toast from "react-hot-toast";

export default function ClienteForm({ cliente }) {
  const { user } = useAuth();
  const router = useRouter();
  const [form, setForm] = useState({
    nome: cliente?.nome || "",
    documento: cliente?.documento || "",
    telefone: cliente?.telefone || "",
    whatsapp: cliente?.whatsapp || "",
    email: cliente?.email || "",
    endereco: cliente?.endereco || "",
    observacoes: cliente?.observacoes || "",
  });
  const [loading, setLoading] = useState(false);

  function update(field, value) {
    setForm((f) => ({ ...f, [field]: value }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setLoading(true);
    let error;
    if (cliente) {
      ({ error } = await supabase.from("clientes").update(form).eq("id", cliente.id));
    } else {
      ({ error } = await supabase.from("clientes").insert({ ...form, oficina_id: user.id }));
    }
    setLoading(false);
    if (error) {
      toast.error("Erro ao salvar cliente.");
      return;
    }
    toast.success("Cliente salvo com sucesso!");
    router.push("/clientes");
  }

  return (
    <form onSubmit={handleSubmit} className="card space-y-4 max-w-2xl">
      <div>
        <label className="label">Nome *</label>
        <input className="input" required value={form.nome} onChange={(e) => update("nome", e.target.value)} />
      </div>
      <div className="grid sm:grid-cols-2 gap-4">
        <div>
          <label className="label">CPF/CNPJ</label>
          <input className="input" value={form.documento} onChange={(e) => update("documento", e.target.value)} />
        </div>
        <div>
          <label className="label">Telefone</label>
          <input className="input" value={form.telefone} onChange={(e) => update("telefone", e.target.value)} />
        </div>
        <div>
          <label className="label">WhatsApp</label>
          <input className="input" placeholder="Ex: 5511999999999" value={form.whatsapp} onChange={(e) => update("whatsapp", e.target.value)} />
        </div>
        <div>
          <label className="label">E-mail</label>
          <input className="input" type="email" value={form.email} onChange={(e) => update("email", e.target.value)} />
        </div>
      </div>
      <div>
        <label className="label">Endereço</label>
        <input className="input" value={form.endereco} onChange={(e) => update("endereco", e.target.value)} />
      </div>
      <div>
        <label className="label">Observações</label>
        <textarea className="input" rows={3} value={form.observacoes} onChange={(e) => update("observacoes", e.target.value)} />
      </div>
      <div className="flex gap-3">
        <button className="btn-primary" disabled={loading}>{loading ? "Salvando..." : "Salvar cliente"}</button>
      </div>
    </form>
  );
}
