"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useAuth } from "@/lib/AuthContext";
import { supabase } from "@/lib/supabaseClient";

const NAV = [
  { href: "/dashboard", label: "Dashboard", icon: "🏠" },
  { href: "/clientes", label: "Clientes", icon: "👤" },
  { href: "/veiculos", label: "Veículos", icon: "🚗" },
  { href: "/orcamentos", label: "Orçamentos", icon: "📄" },
  { href: "/ordens", label: "Ordens de Serviço", icon: "🔧" },
];

export default function AppShell({ children }) {
  const { session, loading, oficina } = useAuth();
  const router = useRouter();
  const pathname = usePathname();
  const [menuAberto, setMenuAberto] = useState(false);

  useEffect(() => {
    if (!loading && !session) {
      router.replace("/login");
    }
  }, [loading, session, router]);

  async function handleLogout() {
    await supabase.auth.signOut();
    router.replace("/login");
  }

  if (loading || !session) {
    return (
      <div className="min-h-screen flex items-center justify-center text-gray-500">
        Carregando...
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 sm:flex">
      {/* Sidebar desktop */}
      <aside className="hidden sm:flex sm:flex-col w-64 bg-white border-r border-gray-100 shrink-0">
        <div className="px-5 py-5 border-b border-gray-100">
          <p className="font-extrabold text-brand-700">Oficina Fácil</p>
          <p className="text-xs text-gray-500 truncate mt-0.5">{oficina?.nome_oficina || "Minha oficina"}</p>
        </div>
        <nav className="flex-1 px-3 py-4 space-y-1">
          {NAV.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium ${
                pathname.startsWith(item.href) ? "bg-brand-50 text-brand-700" : "text-gray-600 hover:bg-gray-50"
              }`}
            >
              <span>{item.icon}</span>
              {item.label}
            </Link>
          ))}
        </nav>
        <div className="p-3 border-t border-gray-100">
          <button onClick={handleLogout} className="btn-secondary w-full text-sm">Sair</button>
        </div>
      </aside>

      {/* Top bar mobile */}
      <div className="sm:hidden flex items-center justify-between bg-white border-b border-gray-100 px-4 py-3 sticky top-0 z-20">
        <span className="font-extrabold text-brand-700">Oficina Fácil</span>
        <button onClick={() => setMenuAberto(true)} className="text-2xl leading-none" aria-label="Abrir menu">☰</button>
      </div>

      {/* Menu mobile (drawer) */}
      {menuAberto && (
        <div className="sm:hidden fixed inset-0 z-30 bg-black/40" onClick={() => setMenuAberto(false)}>
          <div className="absolute right-0 top-0 h-full w-64 bg-white p-4 flex flex-col" onClick={(e) => e.stopPropagation()}>
            <div className="flex justify-between items-center mb-4">
              <p className="font-bold text-brand-700">Menu</p>
              <button onClick={() => setMenuAberto(false)} className="text-xl">✕</button>
            </div>
            <nav className="flex-1 space-y-1">
              {NAV.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  onClick={() => setMenuAberto(false)}
                  className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium ${
                    pathname.startsWith(item.href) ? "bg-brand-50 text-brand-700" : "text-gray-600 hover:bg-gray-50"
                  }`}
                >
                  <span>{item.icon}</span>
                  {item.label}
                </Link>
              ))}
            </nav>
            <button onClick={handleLogout} className="btn-secondary w-full text-sm mt-4">Sair</button>
          </div>
        </div>
      )}

      {/* Bottom nav mobile */}
      <nav className="sm:hidden fixed bottom-0 inset-x-0 bg-white border-t border-gray-100 flex justify-around py-2 z-20">
        {NAV.slice(0, 4).map((item) => (
          <Link
            key={item.href}
            href={item.href}
            className={`flex flex-col items-center text-[11px] px-2 ${
              pathname.startsWith(item.href) ? "text-brand-600" : "text-gray-500"
            }`}
          >
            <span className="text-lg">{item.icon}</span>
            {item.label.split(" ")[0]}
          </Link>
        ))}
      </nav>

      <main className="flex-1 px-4 py-5 sm:px-8 sm:py-8 pb-20 sm:pb-8 max-w-6xl w-full mx-auto">
        {children}
      </main>
    </div>
  );
}
