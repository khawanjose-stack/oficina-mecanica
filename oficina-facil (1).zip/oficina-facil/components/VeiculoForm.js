"use client";

import { useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { useAuth } from "@/lib/AuthContext";
import { supabase } from "@/lib/supabaseClient";
import toast from "react-hot-toast";

export default function VeiculoForm({ veiculo }) {
  const { user } = useAuth();
  const router = useRouter();
  const searchParams = useSearchParams();
  const clienteIdPrefill = searchParams.get("cliente_id");

  const [clientes, setClientes] = useState([]);
  const [form, setForm] = useState({
    cliente_id: veiculo?.cliente_id || clienteIdPrefill || "",
    marca: veiculo?.marca || "",
    modelo: veiculo?.modelo || "",
    ano: veiculo?.ano || "",
    placa: veiculo?.placa || "",
    quilometragem: veiculo?.quilometragem || "",
    cor: veiculo?.cor || "",
    observacoes: veiculo?.observacoes || "",
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    async function carregarClientes() {
      if (!user) return;
      const { data } = await supabase.from("clientes").select("id, nome").eq("oficina_id", user.id).order("nome");
      setClientes(data || []);
    }
    carregarClientes();
  }, [user]);

  function update(field, value) {
    setForm((f) => ({ ...f, [field]: value }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (!form.cliente_id) {
      toast.error("Selecione o cliente dono do veículo.");
      return;
    }
    setLoading(true);
    let error;
    if (veiculo) {
      ({ error } = await supabase.from("veiculos").update(form).eq("id", veiculo.id));
    } else {
      ({ error } = await supabase.from("veiculos").insert({ ...form, oficina_id: user.id }));
    }
    setLoading(false);
    if (error) {
      toast.error("Erro ao salvar veículo.");
      return;
    }
    toast.success("Veículo salvo com sucesso!");
    router.push("/veiculos");
  }

  return (
    <form onSubmit={handleSubmit} className="card space-y-4 max-w-2xl">
      <div>
        <label className="label">Cliente *</label>
        <select className="input" required value={form.cliente_id} onChange={(e) => update("cliente_id", e.target.value)}>
          <option value="">Selecione um cliente</option>
          {clientes.map((c) => (
            <option key={c.id} value={c.id}>{c.nome}</option>
          ))}
        </select>
      </div>
      <div className="grid sm:grid-cols-2 gap-4">
        <div>
          <label className="label">Marca</label>
          <input className="input" value={form.marca} onChange={(e) => update("marca", e.target.value)} />
        </div>
        <div>
          <label className="label">Modelo</label>
          <input className="input" value={form.modelo} onChange={(e) => update("modelo", e.target.value)} />
        </div>
        <div>
          <label className="label">Ano</label>
          <input className="input" value={form.ano} onChange={(e) => update("ano", e.target.value)} />
        </div>
        <div>
          <label className="label">Placa</label>
          <input className="input uppercase" value={form.placa} onChange={(e) => update("placa", e.target.value.toUpperCase())} />
        </div>
        <div>
          <label className="label">Quilometragem</label>
          <input className="input" value={form.quilometragem} onChange={(e) => update("quilometragem", e.target.value)} />
        </div>
        <div>
          <label className="label">Cor</label>
          <input className="input" value={form.cor} onChange={(e) => update("cor", e.target.value)} />
        </div>
      </div>
      <div>
        <label className="label">Observações</label>
        <textarea className="input" rows={3} value={form.observacoes} onChange={(e) => update("observacoes", e.target.value)} />
      </div>
      <button className="btn-primary" disabled={loading}>{loading ? "Salvando..." : "Salvar veículo"}</button>
    </form>
  );
}
