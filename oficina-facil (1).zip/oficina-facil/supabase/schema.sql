-- ============================================================
-- OFICINA FÁCIL - Schema do banco de dados (Supabase / Postgres)
-- Versão revisada: segurança multi-tenant, RLS reforçado, triggers
-- endurecidas e numeração de orçamento/OS isolada por oficina.
--
-- Seguro para rodar em um projeto Supabase NOVO (idempotente: pode
-- ser executado mais de uma vez sem erro).
-- Rode este arquivo inteiro no SQL Editor do seu projeto Supabase.
-- ============================================================

create extension if not exists "uuid-ossp";

-- ------------------------------------------------------------
-- 1. OFICINAS (perfil da oficina, 1 por usuário autenticado)
-- ------------------------------------------------------------
create table if not exists oficinas (
  id uuid primary key references auth.users(id) on delete cascade,
  nome_oficina text not null,
  cnpj text,
  telefone text,
  endereco text,
  logo_url text,
  created_at timestamptz default now()
);

alter table oficinas enable row level security;

drop policy if exists "Oficina vê apenas seus próprios dados" on oficinas;
create policy "Oficina vê apenas seus próprios dados"
  on oficinas for select
  using (auth.uid() = id);

drop policy if exists "Oficina atualiza apenas seus próprios dados" on oficinas;
create policy "Oficina atualiza apenas seus próprios dados"
  on oficinas for update
  using (auth.uid() = id)
  with check (auth.uid() = id);

drop policy if exists "Oficina insere seu próprio registro" on oficinas;
create policy "Oficina insere seu próprio registro"
  on oficinas for insert
  with check (auth.uid() = id);

-- Sem policy de DELETE = ninguém consegue apagar a própria linha de
-- oficina pelo app (deleção de conta, se um dia existir, deve passar
-- por uma rotina administrativa separada).

-- ------------------------------------------------------------
-- 2. CLIENTES
-- ------------------------------------------------------------
create table if not exists clientes (
  id uuid primary key default uuid_generate_v4(),
  oficina_id uuid not null references oficinas(id) on delete cascade,
  nome text not null,
  documento text, -- CPF/CNPJ
  telefone text,
  whatsapp text,
  email text,
  endereco text,
  observacoes text,
  created_at timestamptz default now()
);

create index if not exists idx_clientes_oficina on clientes(oficina_id);
alter table clientes enable row level security;

drop policy if exists "Isolamento clientes" on clientes;
create policy "Isolamento clientes" on clientes
  for all
  using (auth.uid() = oficina_id)
  with check (auth.uid() = oficina_id);

-- ------------------------------------------------------------
-- 3. VEÍCULOS
-- ------------------------------------------------------------
create table if not exists veiculos (
  id uuid primary key default uuid_generate_v4(),
  oficina_id uuid not null references oficinas(id) on delete cascade,
  cliente_id uuid not null references clientes(id) on delete cascade,
  marca text,
  modelo text,
  ano text,
  placa text,
  quilometragem text,
  cor text,
  observacoes text,
  created_at timestamptz default now()
);

create index if not exists idx_veiculos_oficina on veiculos(oficina_id);
create index if not exists idx_veiculos_cliente on veiculos(cliente_id);
alter table veiculos enable row level security;

-- Além de exigir oficina_id = auth.uid(), o WITH CHECK garante que o
-- cliente_id informado pertence a essa MESMA oficina — impede vincular
-- um veículo a um cliente de outra oficina.
drop policy if exists "Isolamento veiculos" on veiculos;
create policy "Isolamento veiculos" on veiculos
  for all
  using (auth.uid() = oficina_id)
  with check (
    auth.uid() = oficina_id
    and exists (
      select 1 from clientes c
      where c.id = veiculos.cliente_id
        and c.oficina_id = auth.uid()
    )
  );

-- ------------------------------------------------------------
-- 4. CONTADORES DE NUMERAÇÃO (uso interno — sem policies expostas)
--    Usado só pelas funções SECURITY DEFINER abaixo para gerar
--    numero #1, #2, #3... independente para cada oficina, em vez de
--    uma sequência global que vazaria volume de outras oficinas.
-- ------------------------------------------------------------
create table if not exists contadores_numeracao (
  oficina_id uuid not null references oficinas(id) on delete cascade,
  tipo text not null check (tipo in ('orcamento','ordem_servico')),
  ultimo_numero integer not null default 0,
  primary key (oficina_id, tipo)
);

alter table contadores_numeracao enable row level security;
-- Nenhuma policy criada de propósito: o app nunca acessa essa tabela
-- diretamente, só a função proximo_numero() (SECURITY DEFINER) abaixo.
-- Sem policies + RLS ligado = acesso direto sempre negado.

-- ------------------------------------------------------------
-- 5. ORÇAMENTOS
-- ------------------------------------------------------------
create table if not exists orcamentos (
  id uuid primary key default uuid_generate_v4(),
  oficina_id uuid not null references oficinas(id) on delete cascade,
  cliente_id uuid not null references clientes(id) on delete cascade,
  veiculo_id uuid not null references veiculos(id) on delete cascade,
  numero integer, -- preenchido pela trigger trg_orcamentos_numero (por oficina)
  desconto numeric default 0,
  valor_total numeric default 0,
  observacoes text,
  validade date,
  status text default 'pendente' check (status in ('pendente','enviado','aprovado','recusado','expirado')),
  created_at timestamptz default now()
);

create index if not exists idx_orcamentos_oficina on orcamentos(oficina_id);
create index if not exists idx_orcamentos_cliente on orcamentos(cliente_id);
create index if not exists idx_orcamentos_veiculo on orcamentos(veiculo_id);
alter table orcamentos enable row level security;

-- WITH CHECK garante que cliente_id e veiculo_id pertencem à mesma oficina.
drop policy if exists "Isolamento orcamentos" on orcamentos;
create policy "Isolamento orcamentos" on orcamentos
  for all
  using (auth.uid() = oficina_id)
  with check (
    auth.uid() = oficina_id
    and exists (select 1 from clientes c where c.id = orcamentos.cliente_id and c.oficina_id = auth.uid())
    and exists (select 1 from veiculos v where v.id = orcamentos.veiculo_id and v.oficina_id = auth.uid())
  );

-- Itens do orçamento (serviços e peças)
create table if not exists orcamento_itens (
  id uuid primary key default uuid_generate_v4(),
  orcamento_id uuid not null references orcamentos(id) on delete cascade,
  oficina_id uuid not null references oficinas(id) on delete cascade,
  tipo text check (tipo in ('servico','peca')) not null,
  descricao text not null,
  quantidade numeric default 1,
  valor_unitario numeric default 0,
  created_at timestamptz default now()
);

create index if not exists idx_orcamento_itens_orcamento on orcamento_itens(orcamento_id);
create index if not exists idx_orcamento_itens_oficina on orcamento_itens(oficina_id);
alter table orcamento_itens enable row level security;

-- WITH CHECK garante que orcamento_id aponta para um orçamento da mesma oficina.
drop policy if exists "Isolamento orcamento_itens" on orcamento_itens;
create policy "Isolamento orcamento_itens" on orcamento_itens
  for all
  using (auth.uid() = oficina_id)
  with check (
    auth.uid() = oficina_id
    and exists (select 1 from orcamentos o where o.id = orcamento_itens.orcamento_id and o.oficina_id = auth.uid())
  );

-- ------------------------------------------------------------
-- 6. ORDENS DE SERVIÇO
-- ------------------------------------------------------------
create table if not exists ordens_servico (
  id uuid primary key default uuid_generate_v4(),
  oficina_id uuid not null references oficinas(id) on delete cascade,
  cliente_id uuid not null references clientes(id) on delete cascade,
  veiculo_id uuid not null references veiculos(id) on delete cascade,
  orcamento_id uuid references orcamentos(id) on delete set null,
  numero integer, -- preenchido pela trigger trg_os_numero (por oficina)
  problema_relatado text,
  diagnostico text,
  valor_mao_obra numeric default 0,
  valor_pecas numeric default 0,
  desconto numeric default 0,
  valor_total numeric default 0,
  status text default 'aberta' check (status in ('aberta','em_andamento','aguardando_aprovacao','concluida','entregue','cancelada')),
  created_at timestamptz default now()
);

create index if not exists idx_os_oficina on ordens_servico(oficina_id);
create index if not exists idx_os_cliente on ordens_servico(cliente_id);
create index if not exists idx_os_veiculo on ordens_servico(veiculo_id);
create index if not exists idx_os_orcamento on ordens_servico(orcamento_id);
alter table ordens_servico enable row level security;

-- WITH CHECK garante cliente_id, veiculo_id e (se preenchido) orcamento_id
-- todos pertencentes à mesma oficina.
drop policy if exists "Isolamento ordens_servico" on ordens_servico;
create policy "Isolamento ordens_servico" on ordens_servico
  for all
  using (auth.uid() = oficina_id)
  with check (
    auth.uid() = oficina_id
    and exists (select 1 from clientes c where c.id = ordens_servico.cliente_id and c.oficina_id = auth.uid())
    and exists (select 1 from veiculos v where v.id = ordens_servico.veiculo_id and v.oficina_id = auth.uid())
    and (
      ordens_servico.orcamento_id is null
      or exists (select 1 from orcamentos o where o.id = ordens_servico.orcamento_id and o.oficina_id = auth.uid())
    )
  );

-- Itens da OS (serviços realizados / peças utilizadas)
create table if not exists os_itens (
  id uuid primary key default uuid_generate_v4(),
  os_id uuid not null references ordens_servico(id) on delete cascade,
  oficina_id uuid not null references oficinas(id) on delete cascade,
  tipo text check (tipo in ('servico','peca')) not null,
  descricao text not null,
  quantidade numeric default 1,
  valor_unitario numeric default 0,
  created_at timestamptz default now()
);

create index if not exists idx_os_itens_os on os_itens(os_id);
create index if not exists idx_os_itens_oficina on os_itens(oficina_id);
alter table os_itens enable row level security;

-- WITH CHECK garante que os_id aponta para uma OS da mesma oficina.
drop policy if exists "Isolamento os_itens" on os_itens;
create policy "Isolamento os_itens" on os_itens
  for all
  using (auth.uid() = oficina_id)
  with check (
    auth.uid() = oficina_id
    and exists (select 1 from ordens_servico o where o.id = os_itens.os_id and o.oficina_id = auth.uid())
  );

-- ============================================================
-- 7. FUNÇÕES E TRIGGERS
-- ============================================================

-- 7.1 — Cria automaticamente a linha em "oficinas" quando um novo
-- usuário se cadastra (usa o nome enviado no signup).
-- SECURITY DEFINER com search_path fixo: evita o ataque conhecido de
-- "search_path hijacking" em funções privilegiadas.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public, pg_temp
as $$
begin
  insert into public.oficinas (id, nome_oficina)
  values (new.id, coalesce(new.raw_user_meta_data->>'nome_oficina', 'Minha Oficina'));
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- 7.2 — Numeração sequencial por oficina (#1, #2, #3...), em vez de
-- uma sequência global que revelaria o volume de outras oficinas.
-- O incremento usa INSERT ... ON CONFLICT DO UPDATE, que é atômico no
-- Postgres — seguro mesmo com duas inserções simultâneas.
create or replace function public.proximo_numero(p_oficina_id uuid, p_tipo text)
returns integer
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  novo_numero integer;
begin
  insert into contadores_numeracao (oficina_id, tipo, ultimo_numero)
  values (p_oficina_id, p_tipo, 1)
  on conflict (oficina_id, tipo)
  do update set ultimo_numero = contadores_numeracao.ultimo_numero + 1
  returning ultimo_numero into novo_numero;

  return novo_numero;
end;
$$;

create or replace function public.set_numero_orcamento()
returns trigger
language plpgsql
security definer
set search_path = public, pg_temp
as $$
begin
  if new.numero is null then
    new.numero := public.proximo_numero(new.oficina_id, 'orcamento');
  end if;
  return new;
end;
$$;

drop trigger if exists trg_orcamentos_numero on orcamentos;
create trigger trg_orcamentos_numero
  before insert on orcamentos
  for each row execute procedure public.set_numero_orcamento();

create or replace function public.set_numero_os()
returns trigger
language plpgsql
security definer
set search_path = public, pg_temp
as $$
begin
  if new.numero is null then
    new.numero := public.proximo_numero(new.oficina_id, 'ordem_servico');
  end if;
  return new;
end;
$$;

drop trigger if exists trg_os_numero on ordens_servico;
create trigger trg_os_numero
  before insert on ordens_servico
  for each row execute procedure public.set_numero_os();

-- ============================================================
-- RESUMO DE SEGURANÇA (para conferência)
-- ============================================================
-- • Toda tabela de dados tem RLS ligado e uma policy "for all" que
--   exige oficina_id = auth.uid() tanto para ler quanto para gravar.
-- • veiculos, orcamentos, orcamento_itens, ordens_servico e os_itens
--   também validam, no WITH CHECK, que qualquer cliente_id/veiculo_id/
--   orcamento_id/os_id referenciado pertence à MESMA oficina — não dá
--   para "linkar" um registro seu a um dado de outra oficina.
-- • contadores_numeracao não tem nenhuma policy: acesso direto do app
--   é sempre negado; só as funções SECURITY DEFINER conseguem gravar.
-- • Funções SECURITY DEFINER têm search_path fixo (public, pg_temp),
--   fechando a brecha de "search_path hijacking".
-- • Numeração de orçamento/OS é isolada por oficina (não vaza volume
--   de outras oficinas via numeração global).
-- ============================================================
