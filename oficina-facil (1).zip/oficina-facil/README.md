# Oficina Fácil — MVP funcional

Sistema web para oficinas mecânicas controlarem clientes, veículos, orçamentos
e ordens de serviço, com geração de PDF e envio de orçamento pelo WhatsApp.

Stack: **Next.js 14 (App Router) + Supabase (Auth + Postgres + RLS) + Tailwind CSS**.

---

## 1. Estrutura do projeto

```
oficina-facil/
├── middleware.js                   → Renova a sessão em cada navegação e protege rotas
├── utils/
│   └── supabase/
│       ├── client.js               → Cliente Supabase para o navegador (cookies)
│       ├── server.js               → Cliente Supabase para Server Components
│       └── middleware.js           → Lógica de renovação de sessão + redirecionamento
├── app/
│   ├── page.js                     → Landing page (rota "/")
│   ├── layout.js                   → Layout raiz (fontes, toaster, AuthProvider)
│   ├── globals.css                 → Tailwind + estilos utilitários (.btn, .card, .input)
│   ├── (auth)/
│   │   ├── login/page.js           → Tela de login
│   │   └── cadastro/page.js        → Tela de cadastro (cria a oficina)
│   └── (app)/                      → Área logada (protegida)
│       ├── layout.js               → Usa o AppShell (sidebar/menu)
│       ├── dashboard/page.js       → Indicadores + atalhos
│       ├── clientes/               → Lista, novo, [id] (editar + histórico)
│       ├── veiculos/               → Lista, novo, [id] (editar + histórico)
│       ├── orcamentos/             → Lista, novo (itens + cálculo), [id] (PDF/WhatsApp/OS)
│       └── ordens/                 → Lista, novo, [id] (detalhe + status)
├── components/
│   ├── AppShell.js                 → Sidebar desktop + menu/bottom nav mobile
│   ├── ClienteForm.js
│   └── VeiculoForm.js
├── lib/
│   ├── supabaseClient.js           → Reexporta o cliente de utils/supabase/client.js
│   ├── AuthContext.js              → Contexto de sessão + dados da oficina logada
│   ├── format.js                   → Formatação de moeda/data, cálculo de totais, status
│   ├── pdfOrcamento.js             → Geração do PDF do orçamento (jsPDF)
│   └── whatsapp.js                 → Monta a mensagem e o link wa.me
└── supabase/
    └── schema.sql                  → Todo o banco de dados + Row Level Security
```

Cada arquivo dentro de `app/` é uma rota real do Next.js (App Router). As pastas
entre parênteses — `(auth)` e `(app)` — são "grupos de rotas": organizam o
código sem aparecer na URL.

O `middleware.js` roda antes de qualquer página, em todo carregamento — é ele
que garante que a sessão continue válida (renovando o token quando necessário)
e que redireciona automaticamente: sem login tentando abrir o dashboard → vai
pro `/login`; já logado tentando abrir `/login` → vai direto pro `/dashboard`.

---

## 2. Banco de dados (Supabase / PostgreSQL)

O arquivo `supabase/schema.sql` cria:

- **oficinas** — 1 registro por conta (dono do login). Criado automaticamente
  por um trigger assim que alguém se cadastra.
- **clientes** — vinculados a `oficina_id`.
- **veiculos** — vinculados a `cliente_id` e `oficina_id`.
- **orcamentos** + **orcamento_itens** (serviços/peças do orçamento).
- **ordens_servico** + **os_itens** (serviços/peças da OS).

Todas as tabelas têm **Row Level Security (RLS)** habilitado com policies do
tipo `auth.uid() = oficina_id`, ou seja: **cada oficina só enxerga e só
consegue alterar os próprios dados**, garantido pelo próprio banco (não só
pela interface).

Um **trigger** (`handle_new_user`) cria automaticamente a linha da oficina na
tabela `oficinas` no momento do cadastro, usando o nome informado no
formulário.

---

## 3. Como configurar o Supabase

1. Crie uma conta e um projeto em https://supabase.com.
2. No painel do projeto, vá em **SQL Editor** → **New query**.
3. Cole todo o conteúdo do arquivo `supabase/schema.sql` e execute (▶ Run).
4. Vá em **Project Settings → API** e copie:
   - `Project URL`
   - `anon public key`
5. (Opcional, recomendado) Em **Authentication → Providers → Email**, você
   pode desativar a confirmação por e-mail durante os testes, em
   **Authentication → Settings → "Confirm email"**, para poder logar
   imediatamente após o cadastro.

---

## 4. Variáveis de ambiente

Este projeto usa `@supabase/ssr` (o pacote oficial mais recente do Supabase para Next.js,
com sessão guardada em cookies em vez de só localStorage — muito mais confiável
entre recarregar a página, fechar o navegador e voltar depois).

O arquivo `.env.local` já vem preenchido com as credenciais do seu projeto Supabase:

```
NEXT_PUBLIC_SUPABASE_URL=https://tvqdhydopyaxttnrqara.supabase.co
NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY=sb_publishable_cHv2N5_DR9cgG-DueCIlpA_RNs4unFv
```

Esse arquivo **nunca deve ser enviado ao GitHub** (o `.gitignore` já está configurado
para ignorá-lo). Ao publicar (Vercel, Netlify etc.), essas mesmas duas variáveis
precisam ser cadastradas manualmente no painel da plataforma de hospedagem.

---

## 5. Como executar localmente

Pré-requisito: Node.js 18 ou superior.

```bash
cd oficina-facil
npm install
npm run dev
```

Acesse http://localhost:3000 — a landing page abre em "/". Para testar o
sistema, clique em "Começar grátis" ou vá direto em `/cadastro`.

---

## 6. Como publicar (deploy)

A forma mais simples é a **Vercel** (criadora do Next.js):

1. Suba o projeto para um repositório no GitHub.
2. Em https://vercel.com, clique em "New Project" e importe o repositório.
3. Em "Environment Variables", adicione as mesmas duas variáveis do
   `.env.local`.
4. Clique em "Deploy". Em poucos minutos você recebe uma URL pública
   (ex: `oficina-facil.vercel.app`).

Você também pode publicar em Netlify ou em qualquer serviço que suporte
Next.js.

---

## 7. Como criar o primeiro usuário/oficina

Basta acessar `/cadastro` (na landing page: "Começar grátis") e preencher:

- Nome da oficina
- E-mail
- Senha

Ao enviar, o Supabase Auth cria o usuário e o trigger do banco cria
automaticamente a linha correspondente na tabela `oficinas`. Você já cai
direto no dashboard (ou precisa confirmar o e-mail, dependendo da
configuração do passo 3 acima).

---

## 8. O que ainda precisa ser configurado/ajustado por você

- **Confirmação de e-mail**: decida se quer manter a confirmação por e-mail
  ativada em produção (mais seguro) ou desativada (cadastro mais rápido).
- **Logo da oficina**: o campo `logo_url` já existe na tabela `oficinas`,
  mas o upload de imagem (Supabase Storage) não foi implementado no MVP —
  hoje o PDF usa apenas o nome da oficina em texto.
- **Numeração de orçamento/OS**: usa `serial` do Postgres (sequencial global
  no banco). Se quiser numeração separada por oficina, é preciso ajustar
  a lógica no banco.
- **Domínio próprio**: configure na Vercel/Netlify após o deploy.
- **Textos legais**: a landing page não inclui Termos de Uso nem Política de
  Privacidade — adicione antes de divulgar publicamente.

---

## 9. Funcionalidades futuras (propositalmente NÃO implementadas agora)

O banco e o código foram organizados para permitir adicionar depois, sem
retrabalho:

- Pagamentos recorrentes e planos (ex: Stripe)
- Notificações (e-mail/WhatsApp automático)
- Controle de estoque de peças
- Fluxo de caixa
- Lembretes de manutenção preventiva
- Relatórios avançados
- IA para diagnóstico/orçamento assistido

Nenhuma dessas foi incluída no MVP, conforme solicitado — o foco foi
entregar login, clientes, veículos, orçamentos, PDF, WhatsApp, ordens de
serviço e dashboard, 100% funcionais.
