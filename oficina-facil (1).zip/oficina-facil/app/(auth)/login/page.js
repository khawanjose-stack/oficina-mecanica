"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { supabase } from "@/lib/supabaseClient";
import toast from "react-hot-toast";

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleLogin(e) {
    e.preventDefault();
    setLoading(true);
    const { data, error } = await supabase.auth.signInWithPassword({ email, password: senha });
    setLoading(false);

    if (error) {
      const msg = (error.message || "").toLowerCase();
      if (msg.includes("email not confirmed")) {
        toast.error("Confirme seu e-mail antes de entrar. Verifique sua caixa de entrada (e o spam).");
      } else if (msg.includes("invalid login credentials")) {
        toast.error("E-mail ou senha incorretos.");
      } else {
        toast.error(error.message || "Não foi possível entrar. Tente novamente.");
      }
      return;
    }

    if (!data.session) {
      toast.error("Não foi possível iniciar a sessão. Tente novamente.");
      return;
    }

    toast.success("Bem-vindo de volta!");
    router.push("/dashboard");
  }

  return (
    <main className="min-h-screen flex items-center justify-center bg-gray-50 px-6">
      <div className="card w-full max-w-md">
        <h1 className="text-xl font-bold text-center text-brand-700">Oficina Fácil</h1>
        <p className="text-center text-sm text-gray-500 mt-1 mb-6">Entre na sua conta</p>
        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <label className="label">E-mail</label>
            <input className="input" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="voce@oficina.com" />
          </div>
          <div>
            <label className="label">Senha</label>
            <input className="input" type="password" required value={senha} onChange={(e) => setSenha(e.target.value)} placeholder="••••••••" />
          </div>
          <button className="btn-primary w-full" disabled={loading}>
            {loading ? "Entrando..." : "Entrar"}
          </button>
        </form>
        <p className="text-center text-sm text-gray-500 mt-6">
          Não tem conta?{" "}
          <Link href="/cadastro" className="text-brand-600 font-semibold">Criar conta grátis</Link>
        </p>
      </div>
    </main>
  );
}
