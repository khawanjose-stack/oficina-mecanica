"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { supabase } from "@/lib/supabaseClient";
import toast from "react-hot-toast";

export default function CadastroPage() {
  const router = useRouter();
  const [nomeOficina, setNomeOficina] = useState("");
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleCadastro(e) {
    e.preventDefault();
    setLoading(true);
    const { data, error } = await supabase.auth.signUp({
      email,
      password: senha,
      options: { data: { nome_oficina: nomeOficina } },
    });
    setLoading(false);

    if (error) {
      const msg = (error.message || "").toLowerCase();
      if (msg.includes("already registered") || msg.includes("already exists")) {
        toast.error("Este e-mail já tem uma conta. Faça login.");
        router.push("/login");
        return;
      }
      toast.error(error.message || "Erro ao criar conta.");
      return;
    }

    // Quando o e-mail já existe mas ainda não foi confirmado, o Supabase não
    // retorna erro — só devolve um usuário sem "identities". É assim que
    // detectamos que não é, de fato, uma conta nova.
    const contaJaExistia = data.user && Array.isArray(data.user.identities) && data.user.identities.length === 0;
    if (contaJaExistia) {
      toast.error("Este e-mail já tem uma conta. Verifique sua caixa de entrada para confirmar, ou faça login.");
      router.push("/login");
      return;
    }

    if (data.session) {
      toast.success("Conta criada! Bem-vindo(a).");
      router.push("/dashboard");
    } else {
      toast.success("Conta criada! Verifique seu e-mail para confirmar antes de entrar.");
      router.push("/login");
    }
  }

  return (
    <main className="min-h-screen flex items-center justify-center bg-gray-50 px-6">
      <div className="card w-full max-w-md">
        <h1 className="text-xl font-bold text-center text-brand-700">Oficina Fácil</h1>
        <p className="text-center text-sm text-gray-500 mt-1 mb-6">Crie sua conta grátis — 7 dias de teste</p>
        <form onSubmit={handleCadastro} className="space-y-4">
          <div>
            <label className="label">Nome da oficina</label>
            <input className="input" required value={nomeOficina} onChange={(e) => setNomeOficina(e.target.value)} placeholder="Ex: Auto Center Silva" />
          </div>
          <div>
            <label className="label">E-mail</label>
            <input className="input" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
          </div>
          <div>
            <label className="label">Senha</label>
            <input className="input" type="password" minLength={6} required value={senha} onChange={(e) => setSenha(e.target.value)} placeholder="Mínimo 6 caracteres" />
          </div>
          <button className="btn-primary w-full" disabled={loading}>
            {loading ? "Criando conta..." : "Começar grátis"}
          </button>
        </form>
        <p className="text-center text-sm text-gray-500 mt-6">
          Já tem conta?{" "}
          <Link href="/login" className="text-brand-600 font-semibold">Entrar</Link>
        </p>
      </div>
    </main>
  );
}
