import Link from "next/link";

const beneficios = [
  { titulo: "Orçamentos em minutos", texto: "Monte orçamentos profissionais com cálculo automático de peças, serviços e desconto." },
  { titulo: "Envio direto pelo WhatsApp", texto: "Um clique e o orçamento já chega pronto no WhatsApp do cliente." },
  { titulo: "Controle total da oficina", texto: "Clientes, veículos e ordens de serviço organizados em um só lugar, sem planilhas." },
  { titulo: "Acesso de qualquer lugar", texto: "Funciona no celular, tablet ou computador — sem instalar nada." },
];

const funcionalidades = [
  "Cadastro de clientes e veículos",
  "Orçamentos com PDF profissional",
  "Envio automático pelo WhatsApp",
  "Ordens de serviço completas",
  "Dashboard com indicadores da oficina",
  "Busca rápida por cliente, placa ou modelo",
];

const passos = [
  { n: "1", t: "Cadastre sua oficina", d: "Crie sua conta gratuita em menos de 2 minutos." },
  { n: "2", t: "Cadastre clientes e veículos", d: "Organize sua carteira de clientes em um só lugar." },
  { n: "3", t: "Monte orçamentos e envie", d: "Gere o PDF e envie pelo WhatsApp com um clique." },
];

const faq = [
  { p: "Preciso instalar algum programa?", r: "Não. O Oficina Fácil funciona direto no navegador, do celular ou computador." },
  { p: "Meus dados ficam seguros?", r: "Sim. Cada oficina só enxerga os próprios dados, protegidos por autenticação segura." },
  { p: "Posso cancelar quando quiser?", r: "Sim, sem fidelidade e sem multa." },
  { p: "Como funciona o teste grátis?", r: "Você usa todas as funções por 7 dias sem pagar nada." },
];

export default function LandingPage() {
  return (
    <main className="min-h-screen bg-white">
      <header className="max-w-6xl mx-auto flex items-center justify-between px-6 py-5">
        <span className="text-xl font-extrabold text-brand-700">Oficina Fácil</span>
        <div className="flex gap-3">
          <Link href="/login" className="btn-secondary hidden sm:inline-flex">Entrar</Link>
          <Link href="/cadastro" className="btn-primary">Começar grátis</Link>
        </div>
      </header>

      <section className="max-w-6xl mx-auto px-6 pt-10 pb-16 text-center">
        <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-gray-900 max-w-3xl mx-auto">
          Controle sua oficina de forma simples e profissional.
        </h1>
        <p className="mt-5 text-lg text-gray-600 max-w-2xl mx-auto">
          Faça orçamentos, gerencie clientes e veículos e envie tudo pelo WhatsApp em poucos cliques.
        </p>
        <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-3">
          <Link href="/cadastro" className="btn-primary text-base px-6 py-3.5">Começar grátis por 7 dias</Link>
          <a href="#como-funciona" className="btn-secondary text-base px-6 py-3.5">Ver como funciona</a>
        </div>

        <div className="mt-14 mx-auto max-w-4xl rounded-2xl border border-gray-100 shadow-xl overflow-hidden bg-gray-50">
          <div className="bg-brand-500 text-white text-left px-6 py-4">
            <p className="text-sm opacity-80">Dashboard</p>
            <p className="text-lg font-semibold">Oficina do João</p>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-6 text-left">
            {[
              { l: "Clientes", v: "128" },
              { l: "Veículos", v: "204" },
              { l: "Orçamentos pendentes", v: "9" },
              { l: "OS abertas", v: "5" },
            ].map((s) => (
              <div key={s.l} className="card">
                <p className="text-xs text-gray-500">{s.l}</p>
                <p className="text-2xl font-bold text-gray-900">{s.v}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-gray-50 py-16">
        <div className="max-w-6xl mx-auto px-6">
          <h2 className="text-2xl sm:text-3xl font-bold text-center mb-10">Por que usar o Oficina Fácil</h2>
          <div className="grid sm:grid-cols-2 gap-6">
            {beneficios.map((b) => (
              <div key={b.titulo} className="card">
                <h3 className="font-semibold text-lg text-brand-700">{b.titulo}</h3>
                <p className="text-gray-600 mt-2 text-sm">{b.texto}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16">
        <div className="max-w-6xl mx-auto px-6">
          <h2 className="text-2xl sm:text-3xl font-bold text-center mb-10">Tudo que sua oficina precisa</h2>
          <ul className="grid sm:grid-cols-2 gap-4 max-w-3xl mx-auto">
            {funcionalidades.map((f) => (
              <li key={f} className="flex items-center gap-3 card">
                <span className="text-brand-500 font-bold">✓</span>
                <span className="text-gray-700 text-sm">{f}</span>
              </li>
            ))}
          </ul>
        </div>
      </section>

      <section id="como-funciona" className="bg-gray-50 py-16">
        <div className="max-w-5xl mx-auto px-6">
          <h2 className="text-2xl sm:text-3xl font-bold text-center mb-10">Como funciona</h2>
          <div className="grid sm:grid-cols-3 gap-6">
            {passos.map((p) => (
              <div key={p.n} className="card text-center">
                <div className="mx-auto w-10 h-10 rounded-full bg-brand-500 text-white flex items-center justify-center font-bold mb-3">
                  {p.n}
                </div>
                <h3 className="font-semibold">{p.t}</h3>
                <p className="text-sm text-gray-600 mt-2">{p.d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="precos" className="py-16">
        <div className="max-w-3xl mx-auto px-6 text-center">
          <h2 className="text-2xl sm:text-3xl font-bold mb-10">Preço simples e justo</h2>
          <div className="card max-w-sm mx-auto">
            <p className="text-sm text-gray-500">Plano único</p>
            <p className="text-4xl font-extrabold mt-2">R$29,90<span className="text-base font-medium text-gray-500">/mês</span></p>
            <p className="text-sm text-brand-600 font-semibold mt-2">7 dias grátis para testar</p>
            <ul className="text-sm text-gray-600 mt-5 space-y-2 text-left">
              <li>✓ Clientes e veículos ilimitados</li>
              <li>✓ Orçamentos e OS ilimitados</li>
              <li>✓ PDF profissional</li>
              <li>✓ Envio pelo WhatsApp</li>
            </ul>
            <Link href="/cadastro" className="btn-primary w-full mt-6">Começar grátis</Link>
          </div>
        </div>
      </section>

      <section className="bg-gray-50 py-16">
        <div className="max-w-3xl mx-auto px-6">
          <h2 className="text-2xl sm:text-3xl font-bold text-center mb-10">Perguntas frequentes</h2>
          <div className="space-y-4">
            {faq.map((f) => (
              <div key={f.p} className="card">
                <p className="font-semibold">{f.p}</p>
                <p className="text-sm text-gray-600 mt-2">{f.r}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 text-center px-6">
        <h2 className="text-2xl sm:text-3xl font-bold">Pronto para organizar sua oficina?</h2>
        <p className="text-gray-600 mt-3">Comece agora, é grátis por 7 dias.</p>
        <Link href="/cadastro" className="btn-primary text-base px-8 py-3.5 mt-6 inline-flex">Começar grátis</Link>
      </section>

      <footer className="border-t border-gray-100 py-8 text-center text-sm text-gray-500">
        © {new Date().getFullYear()} Oficina Fácil. Todos os direitos reservados.
      </footer>
    </main>
  );
}
