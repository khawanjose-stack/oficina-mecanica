import ClienteForm from "@/components/ClienteForm";

export default function NovoClientePage() {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-5">Novo Cliente</h1>
      <ClienteForm />
    </div>
  );
}
