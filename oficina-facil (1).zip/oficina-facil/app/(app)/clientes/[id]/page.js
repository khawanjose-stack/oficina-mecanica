"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useParams } from "next/navigation";
import { supabase } from "@/lib/supabaseClient";
import ClienteForm from "@/components/ClienteForm";
import { formatMoney, formatDate, STATUS_ORCAMENTO, STATUS_OS } from "@/lib/format";

export default function ClienteDetalhePage() {
  const { id } = useParams();
  const [cliente, setCliente] = useState(null);
  const [veiculos, setVeiculos] = useState([]);
  const [orcamentos, setOrcamentos] = useState([]);
  const [ordens, setOrdens] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function carregar() {
      const [clienteRes, veiculosRes, orcamentosRes, ordensRes] = await Promise.all([
        supabase.from("clientes").select("*").eq("id", id).single(),
        supabase.from("veiculos").select("*").eq("cliente_id", id).order("created_at", { ascending: false }),
        supabase.from("orcamentos").select("*").eq("cliente_id", id).order("created_at", { ascending: false }),
        supabase.from("ordens_servico").select("*").eq("cliente_id", id).order("created_at", { ascending: false }),
      ]);
      setCliente(clienteRes.data);
      setVeiculos(veiculosRes.data || []);
      setOrcamentos(orcamentosRes.data || []);
      setOrdens(ordensRes.data || []);
      setLoading(false);
    }
    if (id) carregar();
  }, [id]);

  if (loading) return <p className="text-gray-500">Carregando...</p>;
  if (!cliente) return <p className="text-gray-500">Cliente não encontrado.</p>;

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold mb-5">Editar Cliente</h1>
        <ClienteForm cliente={cliente} />
      </div>

      <div>
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-semibold text-lg">Veículos</h2>
          <Link href={`/veiculos/novo?cliente_id=${id}`} className="btn-secondary text-sm">+ Novo veículo</Link>
        </div>
        {veiculos.length === 0 && <p className="text-gray-500 text-sm">Nenhum veículo cadastrado.</p>}
        <div className="space-y-2">
          {veiculos.map((v) => (
            <Link key={v.id} href={`/veiculos/${v.id}`} className="card flex items-center justify-between hover:bg-gray-50">
              <span className="font-medium">{v.marca} {v.modelo} {v.ano ? `(${v.ano})` : ""}</span>
              <span className="text-sm text-gray-500">{v.placa}</span>
            </Link>
          ))}
        </div>
      </div>

      <div>
        <h2 className="font-semibold text-lg mb-3">Histórico de orçamentos</h2>
        {orcamentos.length === 0 && <p className="text-gray-500 text-sm">Nenhum orçamento ainda.</p>}
        <div className="space-y-2">
          {orcamentos.map((o) => (
            <Link key={o.id} href={`/orcamentos/${o.id}`} className="card flex items-center justify-between hover:bg-gray-50">
              <span>Orçamento #{o.numero} — {formatDate(o.created_at)}</span>
              <span className="flex items-center gap-3">
                <span className={`text-xs px-2 py-1 rounded-full ${STATUS_ORCAMENTO[o.status]?.color}`}>{STATUS_ORCAMENTO[o.status]?.label}</span>
                <span className="font-semibold">{formatMoney(o.valor_total)}</span>
              </span>
            </Link>
          ))}
        </div>
      </div>

      <div>
        <h2 className="font-semibold text-lg mb-3">Histórico de ordens de serviço</h2>
        {ordens.length === 0 && <p className="text-gray-500 text-sm">Nenhuma OS ainda.</p>}
        <div className="space-y-2">
          {ordens.map((o) => (
            <Link key={o.id} href={`/ordens/${o.id}`} className="card flex items-center justify-between hover:bg-gray-50">
              <span>OS #{o.numero} — {formatDate(o.created_at)}</span>
              <span className="flex items-center gap-3">
                <span className={`text-xs px-2 py-1 rounded-full ${STATUS_OS[o.status]?.color}`}>{STATUS_OS[o.status]?.label}</span>
                <span className="font-semibold">{formatMoney(o.valor_total)}</span>
              </span>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
