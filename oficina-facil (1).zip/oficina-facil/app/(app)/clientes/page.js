"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useAuth } from "@/lib/AuthContext";
import { supabase } from "@/lib/supabaseClient";
import toast from "react-hot-toast";

export default function ClientesPage() {
  const { user } = useAuth();
  const [clientes, setClientes] = useState([]);
  const [busca, setBusca] = useState("");
  const [loading, setLoading] = useState(true);

  async function carregar() {
    if (!user) return;
    setLoading(true);
    let query = supabase.from("clientes").select("*").eq("oficina_id", user.id).order("nome");
    if (busca) {
      query = query.or(`nome.ilike.%${busca}%,telefone.ilike.%${busca}%,whatsapp.ilike.%${busca}%`);
    }
    const { data, error } = await query;
    if (error) toast.error("Erro ao carregar clientes.");
    setClientes(data || []);
    setLoading(false);
  }

  useEffect(() => {
    carregar();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  async function handleBuscaSubmit(e) {
    e.preventDefault();
    carregar();
  }

  async function handleExcluir(id) {
    if (!confirm("Excluir este cliente? Essa ação não pode ser desfeita.")) return;
    const { error } = await supabase.from("clientes").delete().eq("id", id);
    if (error) {
      toast.error("Não foi possível excluir (verifique se há veículos vinculados).");
      return;
    }
    toast.success("Cliente excluído.");
    carregar();
  }

  return (
    <div>
      <div className="flex items-center justify-between flex-wrap gap-3">
        <h1 className="text-2xl font-bold">Clientes</h1>
        <Link href="/clientes/novo" className="btn-primary">+ Novo Cliente</Link>
      </div>

      <form onSubmit={handleBuscaSubmit} className="mt-4 flex gap-2">
        <input
          className="input"
          placeholder="Buscar por nome ou telefone..."
          value={busca}
          onChange={(e) => setBusca(e.target.value)}
        />
        <button className="btn-secondary shrink-0">Buscar</button>
      </form>

      <div className="mt-5 space-y-3">
        {loading && <p className="text-gray-500">Carregando...</p>}
        {!loading && clientes.length === 0 && (
          <p className="text-gray-500">Nenhum cliente cadastrado ainda.</p>
        )}
        {clientes.map((c) => (
          <div key={c.id} className="card flex items-center justify-between gap-4">
            <div className="min-w-0">
              <Link href={`/clientes/${c.id}`} className="font-semibold text-gray-900 hover:underline truncate block">
                {c.nome}
              </Link>
              <p className="text-sm text-gray-500 truncate">{c.telefone || c.whatsapp || c.email || "-"}</p>
            </div>
            <div className="flex gap-2 shrink-0">
              <Link href={`/clientes/${c.id}`} className="btn-secondary text-xs px-3 py-2">Editar</Link>
              <button onClick={() => handleExcluir(c.id)} className="btn-danger text-xs px-3 py-2">Excluir</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
