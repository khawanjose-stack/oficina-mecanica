"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useAuth } from "@/lib/AuthContext";
import { supabase } from "@/lib/supabaseClient";
import { formatMoney, formatDate, STATUS_ORCAMENTO } from "@/lib/format";

export default function OrcamentosPage() {
  const { user } = useAuth();
  const [orcamentos, setOrcamentos] = useState([]);
  const [busca, setBusca] = useState("");
  const [loading, setLoading] = useState(true);

  async function carregar() {
    if (!user) return;
    setLoading(true);
    const { data } = await supabase
      .from("orcamentos")
      .select("*, clientes(nome), veiculos(placa, modelo)")
      .eq("oficina_id", user.id)
      .order("created_at", { ascending: false });
    setOrcamentos(data || []);
    setLoading(false);
  }

  useEffect(() => {
    carregar();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  const filtrados = orcamentos.filter((o) => {
    if (!busca) return true;
    const alvo = `${o.numero} ${o.clientes?.nome || ""} ${o.veiculos?.placa || ""} ${o.veiculos?.modelo || ""}`.toLowerCase();
    return alvo.includes(busca.toLowerCase());
  });

  return (
    <div>
      <div className="flex items-center justify-between flex-wrap gap-3">
        <h1 className="text-2xl font-bold">Orçamentos</h1>
        <Link href="/orcamentos/novo" className="btn-primary">+ Novo Orçamento</Link>
      </div>

      <input
        className="input mt-4"
        placeholder="Buscar por número, cliente ou placa..."
        value={busca}
        onChange={(e) => setBusca(e.target.value)}
      />

      <div className="mt-5 space-y-3">
        {loading && <p className="text-gray-500">Carregando...</p>}
        {!loading && filtrados.length === 0 && <p className="text-gray-500">Nenhum orçamento encontrado.</p>}
        {filtrados.map((o) => (
          <Link key={o.id} href={`/orcamentos/${o.id}`} className="card flex items-center justify-between gap-4 hover:bg-gray-50">
            <div className="min-w-0">
              <p className="font-semibold">Orçamento #{o.numero} — {o.clientes?.nome}</p>
              <p className="text-sm text-gray-500 truncate">{o.veiculos?.modelo} • {o.veiculos?.placa} • {formatDate(o.created_at)}</p>
            </div>
            <div className="text-right shrink-0">
              <span className={`text-xs px-2 py-1 rounded-full ${STATUS_ORCAMENTO[o.status]?.color}`}>{STATUS_ORCAMENTO[o.status]?.label}</span>
              <p className="font-bold mt-1">{formatMoney(o.valor_total)}</p>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
