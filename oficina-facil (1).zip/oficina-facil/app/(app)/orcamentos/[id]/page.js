"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { useAuth } from "@/lib/AuthContext";
import { supabase } from "@/lib/supabaseClient";
import { formatMoney, formatDate, STATUS_ORCAMENTO } from "@/lib/format";
import { gerarPdfOrcamento } from "@/lib/pdfOrcamento";
import { montarMensagemOrcamento, gerarLinkWhatsapp } from "@/lib/whatsapp";
import toast from "react-hot-toast";

export default function OrcamentoDetalhePage() {
  const { id } = useParams();
  const router = useRouter();
  const { oficina } = useAuth();

  const [orcamento, setOrcamento] = useState(null);
  const [cliente, setCliente] = useState(null);
  const [veiculo, setVeiculo] = useState(null);
  const [itens, setItens] = useState([]);
  const [loading, setLoading] = useState(true);
  const [convertendo, setConvertendo] = useState(false);

  async function carregar() {
    setLoading(true);
    const { data: o } = await supabase.from("orcamentos").select("*").eq("id", id).single();
    if (!o) {
      setLoading(false);
      return;
    }
    const [{ data: c }, { data: v }, { data: it }] = await Promise.all([
      supabase.from("clientes").select("*").eq("id", o.cliente_id).single(),
      supabase.from("veiculos").select("*").eq("id", o.veiculo_id).single(),
      supabase.from("orcamento_itens").select("*").eq("orcamento_id", o.id).order("created_at"),
    ]);
    setOrcamento(o);
    setCliente(c);
    setVeiculo(v);
    setItens(it || []);
    setLoading(false);
  }

  useEffect(() => {
    if (id) carregar();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  async function handleStatusChange(status) {
    const { error } = await supabase.from("orcamentos").update({ status }).eq("id", id);
    if (error) {
      toast.error("Erro ao atualizar status.");
      return;
    }
    setOrcamento((o) => ({ ...o, status }));
    toast.success("Status atualizado.");
  }

  function handleGerarPdf() {
    const doc = gerarPdfOrcamento({ oficina, orcamento, cliente, veiculo, itens });
    doc.save(`orcamento-${orcamento.numero}.pdf`);
  }

  function handleEnviarWhatsapp() {
    const mensagem = montarMensagemOrcamento({ oficina, orcamento, cliente, veiculo, itens });
    const link = gerarLinkWhatsapp(cliente?.whatsapp || cliente?.telefone, mensagem);
    window.open(link, "_blank");
    if (orcamento.status === "pendente") handleStatusChange("enviado");
  }

  async function handleTransformarEmOS() {
    setConvertendo(true);
    const { data: os, error } = await supabase
      .from("ordens_servico")
      .insert({
        oficina_id: orcamento.oficina_id,
        cliente_id: orcamento.cliente_id,
        veiculo_id: orcamento.veiculo_id,
        orcamento_id: orcamento.id,
        valor_mao_obra: itens.filter((i) => i.tipo === "servico").reduce((acc, i) => acc + i.quantidade * i.valor_unitario, 0),
        valor_pecas: itens.filter((i) => i.tipo === "peca").reduce((acc, i) => acc + i.quantidade * i.valor_unitario, 0),
        desconto: orcamento.desconto,
        valor_total: orcamento.valor_total,
        status: "aberta",
      })
      .select()
      .single();

    if (error || !os) {
      setConvertendo(false);
      toast.error("Erro ao gerar ordem de serviço.");
      return;
    }

    const itensOs = itens.map((it) => ({
      os_id: os.id,
      oficina_id: orcamento.oficina_id,
      tipo: it.tipo,
      descricao: it.descricao,
      quantidade: it.quantidade,
      valor_unitario: it.valor_unitario,
    }));
    await supabase.from("os_itens").insert(itensOs);
    setConvertendo(false);
    toast.success("Ordem de serviço criada!");
    router.push(`/ordens/${os.id}`);
  }

  if (loading) return <p className="text-gray-500">Carregando...</p>;
  if (!orcamento) return <p className="text-gray-500">Orçamento não encontrado.</p>;

  return (
    <div className="max-w-3xl space-y-5">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <h1 className="text-2xl font-bold">Orçamento #{orcamento.numero}</h1>
        <span className={`text-xs px-3 py-1.5 rounded-full font-medium ${STATUS_ORCAMENTO[orcamento.status]?.color}`}>
          {STATUS_ORCAMENTO[orcamento.status]?.label}
        </span>
      </div>

      <div className="card grid sm:grid-cols-2 gap-4">
        <div>
          <p className="text-xs text-gray-500">Cliente</p>
          <p className="font-semibold">{cliente?.nome}</p>
          <p className="text-sm text-gray-500">{cliente?.telefone || cliente?.whatsapp}</p>
        </div>
        <div>
          <p className="text-xs text-gray-500">Veículo</p>
          <p className="font-semibold">{veiculo?.marca} {veiculo?.modelo} ({veiculo?.ano})</p>
          <p className="text-sm text-gray-500">{veiculo?.placa}</p>
        </div>
      </div>

      <div className="card">
        <h2 className="font-semibold mb-3">Itens</h2>
        <div className="space-y-2">
          {itens.map((it) => (
            <div key={it.id} className="flex justify-between text-sm border-b border-gray-100 pb-2 last:border-0">
              <span>{it.descricao} <span className="text-gray-400">({it.tipo === "servico" ? "Serviço" : "Peça"}) x{it.quantidade}</span></span>
              <span className="font-medium">{formatMoney(it.quantidade * it.valor_unitario)}</span>
            </div>
          ))}
        </div>
        <div className="flex justify-between mt-4 text-sm text-gray-500">
          <span>Desconto</span>
          <span>{formatMoney(orcamento.desconto)}</span>
        </div>
        <div className="flex justify-between mt-1 text-lg font-bold">
          <span>Total</span>
          <span>{formatMoney(orcamento.valor_total)}</span>
        </div>
        {orcamento.observacoes && (
          <div className="mt-4 text-sm text-gray-600">
            <p className="font-medium text-gray-700">Observações</p>
            <p>{orcamento.observacoes}</p>
          </div>
        )}
        <p className="text-xs text-gray-400 mt-4">
          Criado em {formatDate(orcamento.created_at)} • Validade: {orcamento.validade ? formatDate(orcamento.validade) : "-"}
        </p>
      </div>

      <div className="card">
        <h2 className="font-semibold mb-3">Status</h2>
        <div className="flex flex-wrap gap-2">
          {Object.entries(STATUS_ORCAMENTO).map(([key, val]) => (
            <button
              key={key}
              onClick={() => handleStatusChange(key)}
              className={`text-xs px-3 py-2 rounded-full border ${
                orcamento.status === key ? "border-brand-500 bg-brand-50 text-brand-700" : "border-gray-200 text-gray-600"
              }`}
            >
              {val.label}
            </button>
          ))}
        </div>
      </div>

      <div className="flex flex-wrap gap-3">
        <button onClick={handleGerarPdf} className="btn-secondary">📄 Gerar PDF</button>
        <button onClick={handleEnviarWhatsapp} className="btn-primary">📲 Enviar pelo WhatsApp</button>
        {orcamento.status === "aprovado" && (
          <button onClick={handleTransformarEmOS} disabled={convertendo} className="btn-secondary">
            {convertendo ? "Gerando..." : "🔧 Transformar em Ordem de Serviço"}
          </button>
        )}
      </div>
    </div>
  );
}
