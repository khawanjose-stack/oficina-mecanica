"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import { supabase } from "@/lib/supabaseClient";
import { formatMoney, formatDate, STATUS_OS } from "@/lib/format";
import toast from "react-hot-toast";

export default function OsDetalhePage() {
  const { id } = useParams();
  const [os, setOs] = useState(null);
  const [cliente, setCliente] = useState(null);
  const [veiculo, setVeiculo] = useState(null);
  const [itens, setItens] = useState([]);
  const [loading, setLoading] = useState(true);

  async function carregar() {
    setLoading(true);
    const { data: o } = await supabase.from("ordens_servico").select("*").eq("id", id).single();
    if (!o) {
      setLoading(false);
      return;
    }
    const [{ data: c }, { data: v }, { data: it }] = await Promise.all([
      supabase.from("clientes").select("*").eq("id", o.cliente_id).single(),
      supabase.from("veiculos").select("*").eq("id", o.veiculo_id).single(),
      supabase.from("os_itens").select("*").eq("os_id", o.id).order("created_at"),
    ]);
    setOs(o);
    setCliente(c);
    setVeiculo(v);
    setItens(it || []);
    setLoading(false);
  }

  useEffect(() => {
    if (id) carregar();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  async function handleStatusChange(status) {
    const { error } = await supabase.from("ordens_servico").update({ status }).eq("id", id);
    if (error) {
      toast.error("Erro ao atualizar status.");
      return;
    }
    setOs((o) => ({ ...o, status }));
    toast.success("Status atualizado.");
  }

  if (loading) return <p className="text-gray-500">Carregando...</p>;
  if (!os) return <p className="text-gray-500">Ordem de serviço não encontrada.</p>;

  return (
    <div className="max-w-3xl space-y-5">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <h1 className="text-2xl font-bold">Ordem de Serviço #{os.numero}</h1>
        <span className={`text-xs px-3 py-1.5 rounded-full font-medium ${STATUS_OS[os.status]?.color}`}>
          {STATUS_OS[os.status]?.label}
        </span>
      </div>

      <div className="card grid sm:grid-cols-2 gap-4">
        <div>
          <p className="text-xs text-gray-500">Cliente</p>
          <p className="font-semibold">{cliente?.nome}</p>
          <p className="text-sm text-gray-500">{cliente?.telefone || cliente?.whatsapp}</p>
        </div>
        <div>
          <p className="text-xs text-gray-500">Veículo</p>
          <p className="font-semibold">{veiculo?.marca} {veiculo?.modelo} ({veiculo?.ano})</p>
          <p className="text-sm text-gray-500">{veiculo?.placa}</p>
        </div>
      </div>

      {(os.problema_relatado || os.diagnostico) && (
        <div className="card space-y-3">
          {os.problema_relatado && (
            <div>
              <p className="text-xs text-gray-500">Problema relatado</p>
              <p className="text-sm">{os.problema_relatado}</p>
            </div>
          )}
          {os.diagnostico && (
            <div>
              <p className="text-xs text-gray-500">Diagnóstico</p>
              <p className="text-sm">{os.diagnostico}</p>
            </div>
          )}
        </div>
      )}

      <div className="card">
        <h2 className="font-semibold mb-3">Serviços e Peças</h2>
        {itens.length === 0 && <p className="text-sm text-gray-500">Nenhum item registrado.</p>}
        <div className="space-y-2">
          {itens.map((it) => (
            <div key={it.id} className="flex justify-between text-sm border-b border-gray-100 pb-2 last:border-0">
              <span>{it.descricao} <span className="text-gray-400">({it.tipo === "servico" ? "Serviço" : "Peça"}) x{it.quantidade}</span></span>
              <span className="font-medium">{formatMoney(it.quantidade * it.valor_unitario)}</span>
            </div>
          ))}
        </div>
        <div className="flex justify-between mt-4 text-sm text-gray-500">
          <span>Mão de obra</span><span>{formatMoney(os.valor_mao_obra)}</span>
        </div>
        <div className="flex justify-between text-sm text-gray-500">
          <span>Peças</span><span>{formatMoney(os.valor_pecas)}</span>
        </div>
        <div className="flex justify-between text-sm text-gray-500">
          <span>Desconto</span><span>{formatMoney(os.desconto)}</span>
        </div>
        <div className="flex justify-between mt-1 text-lg font-bold">
          <span>Total</span><span>{formatMoney(os.valor_total)}</span>
        </div>
        <p className="text-xs text-gray-400 mt-4">Criada em {formatDate(os.created_at)}</p>
      </div>

      <div className="card">
        <h2 className="font-semibold mb-3">Status</h2>
        <div className="flex flex-wrap gap-2">
          {Object.entries(STATUS_OS).map(([key, val]) => (
            <button
              key={key}
              onClick={() => handleStatusChange(key)}
              className={`text-xs px-3 py-2 rounded-full border ${
                os.status === key ? "border-brand-500 bg-brand-50 text-brand-700" : "border-gray-200 text-gray-600"
              }`}
            >
              {val.label}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
