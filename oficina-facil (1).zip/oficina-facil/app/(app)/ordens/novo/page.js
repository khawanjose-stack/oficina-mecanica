"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/lib/AuthContext";
import { supabase } from "@/lib/supabaseClient";
import { formatMoney } from "@/lib/format";
import toast from "react-hot-toast";

function novoItem() {
  return { id: crypto.randomUUID(), tipo: "servico", descricao: "", quantidade: 1, valor_unitario: 0 };
}

export default function NovaOsPage() {
  const { user } = useAuth();
  const router = useRouter();

  const [clientes, setClientes] = useState([]);
  const [veiculos, setVeiculos] = useState([]);
  const [clienteId, setClienteId] = useState("");
  const [veiculoId, setVeiculoId] = useState("");
  const [problemaRelatado, setProblemaRelatado] = useState("");
  const [diagnostico, setDiagnostico] = useState("");
  const [itens, setItens] = useState([novoItem()]);
  const [desconto, setDesconto] = useState(0);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    async function carregarClientes() {
      if (!user) return;
      const { data } = await supabase.from("clientes").select("id, nome").eq("oficina_id", user.id).order("nome");
      setClientes(data || []);
    }
    carregarClientes();
  }, [user]);

  useEffect(() => {
    async function carregarVeiculos() {
      if (!clienteId) {
        setVeiculos([]);
        return;
      }
      const { data } = await supabase.from("veiculos").select("id, marca, modelo, placa").eq("cliente_id", clienteId);
      setVeiculos(data || []);
      setVeiculoId("");
    }
    carregarVeiculos();
  }, [clienteId]);

  function updateItem(id, field, value) {
    setItens((prev) => prev.map((it) => (it.id === id ? { ...it, [field]: value } : it)));
  }
  function addItem() {
    setItens((prev) => [...prev, novoItem()]);
  }
  function removeItem(id) {
    setItens((prev) => prev.filter((it) => it.id !== id));
  }

  const valorMaoObra = itens.filter((i) => i.tipo === "servico").reduce((acc, i) => acc + Number(i.quantidade || 0) * Number(i.valor_unitario || 0), 0);
  const valorPecas = itens.filter((i) => i.tipo === "peca").reduce((acc, i) => acc + Number(i.quantidade || 0) * Number(i.valor_unitario || 0), 0);
  const total = Math.max(valorMaoObra + valorPecas - Number(desconto || 0), 0);

  async function handleSubmit(e) {
    e.preventDefault();
    if (!clienteId || !veiculoId) {
      toast.error("Selecione o cliente e o veículo.");
      return;
    }
    const itensValidos = itens.filter((it) => it.descricao.trim());

    setLoading(true);
    const { data: os, error } = await supabase
      .from("ordens_servico")
      .insert({
        oficina_id: user.id,
        cliente_id: clienteId,
        veiculo_id: veiculoId,
        problema_relatado: problemaRelatado,
        diagnostico,
        valor_mao_obra: valorMaoObra,
        valor_pecas: valorPecas,
        desconto: Number(desconto) || 0,
        valor_total: total,
        status: "aberta",
      })
      .select()
      .single();

    if (error) {
      setLoading(false);
      toast.error("Erro ao criar ordem de serviço.");
      return;
    }

    if (itensValidos.length > 0) {
      const itensParaInserir = itensValidos.map((it) => ({
        os_id: os.id,
        oficina_id: user.id,
        tipo: it.tipo,
        descricao: it.descricao,
        quantidade: Number(it.quantidade) || 1,
        valor_unitario: Number(it.valor_unitario) || 0,
      }));
      await supabase.from("os_itens").insert(itensParaInserir);
    }

    setLoading(false);
    toast.success("Ordem de serviço criada!");
    router.push(`/ordens/${os.id}`);
  }

  return (
    <div>
      <h1 className="text-2xl font-bold mb-5">Nova Ordem de Serviço</h1>
      <form onSubmit={handleSubmit} className="space-y-5 max-w-3xl">
        <div className="card grid sm:grid-cols-2 gap-4">
          <div>
            <label className="label">Cliente *</label>
            <select className="input" required value={clienteId} onChange={(e) => setClienteId(e.target.value)}>
              <option value="">Selecione um cliente</option>
              {clientes.map((c) => (<option key={c.id} value={c.id}>{c.nome}</option>))}
            </select>
          </div>
          <div>
            <label className="label">Veículo *</label>
            <select className="input" required disabled={!clienteId} value={veiculoId} onChange={(e) => setVeiculoId(e.target.value)}>
              <option value="">{clienteId ? "Selecione um veículo" : "Selecione o cliente primeiro"}</option>
              {veiculos.map((v) => (<option key={v.id} value={v.id}>{v.marca} {v.modelo} — {v.placa}</option>))}
            </select>
          </div>
        </div>

        <div className="card space-y-4">
          <div>
            <label className="label">Problema relatado pelo cliente</label>
            <textarea className="input" rows={2} value={problemaRelatado} onChange={(e) => setProblemaRelatado(e.target.value)} />
          </div>
          <div>
            <label className="label">Diagnóstico</label>
            <textarea className="input" rows={2} value={diagnostico} onChange={(e) => setDiagnostico(e.target.value)} />
          </div>
        </div>

        <div className="card">
          <div className="flex items-center justify-between mb-3">
            <h2 className="font-semibold">Serviços realizados e peças utilizadas</h2>
            <button type="button" onClick={addItem} className="btn-secondary text-sm">+ Adicionar item</button>
          </div>
          <div className="space-y-3">
            {itens.map((it) => (
              <div key={it.id} className="grid grid-cols-12 gap-2 items-end border-b border-gray-100 pb-3 last:border-0">
                <div className="col-span-3 sm:col-span-2">
                  <label className="label">Tipo</label>
                  <select className="input" value={it.tipo} onChange={(e) => updateItem(it.id, "tipo", e.target.value)}>
                    <option value="servico">Serviço</option>
                    <option value="peca">Peça</option>
                  </select>
                </div>
                <div className="col-span-9 sm:col-span-4">
                  <label className="label">Descrição</label>
                  <input className="input" value={it.descricao} onChange={(e) => updateItem(it.id, "descricao", e.target.value)} />
                </div>
                <div className="col-span-4 sm:col-span-2">
                  <label className="label">Qtd</label>
                  <input className="input" type="number" min="0" step="1" value={it.quantidade} onChange={(e) => updateItem(it.id, "quantidade", e.target.value)} />
                </div>
                <div className="col-span-4 sm:col-span-2">
                  <label className="label">Valor unit. (R$)</label>
                  <input className="input" type="number" min="0" step="0.01" value={it.valor_unitario} onChange={(e) => updateItem(it.id, "valor_unitario", e.target.value)} />
                </div>
                <div className="col-span-3 sm:col-span-1 text-sm font-semibold text-right">
                  {formatMoney(Number(it.quantidade || 0) * Number(it.valor_unitario || 0))}
                </div>
                <div className="col-span-1">
                  <button type="button" onClick={() => removeItem(it.id)} className="text-red-500 text-sm">✕</button>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="card grid sm:grid-cols-2 gap-4">
          <div>
            <label className="label">Desconto (R$)</label>
            <input className="input" type="number" min="0" step="0.01" value={desconto} onChange={(e) => setDesconto(e.target.value)} />
          </div>
          <div className="flex flex-col justify-end text-right sm:text-left">
            <p className="text-sm text-gray-500">Mão de obra: {formatMoney(valorMaoObra)} • Peças: {formatMoney(valorPecas)}</p>
            <p className="text-lg font-bold">Total: {formatMoney(total)}</p>
          </div>
        </div>

        <button className="btn-primary" disabled={loading}>{loading ? "Salvando..." : "Salvar ordem de serviço"}</button>
      </form>
    </div>
  );
}
