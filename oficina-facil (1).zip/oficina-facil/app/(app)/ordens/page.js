"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useAuth } from "@/lib/AuthContext";
import { supabase } from "@/lib/supabaseClient";
import { formatMoney, formatDate, STATUS_OS } from "@/lib/format";

export default function OrdensPage() {
  const { user } = useAuth();
  const [ordens, setOrdens] = useState([]);
  const [busca, setBusca] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function carregar() {
      if (!user) return;
      setLoading(true);
      const { data } = await supabase
        .from("ordens_servico")
        .select("*, clientes(nome), veiculos(placa, modelo)")
        .eq("oficina_id", user.id)
        .order("created_at", { ascending: false });
      setOrdens(data || []);
      setLoading(false);
    }
    carregar();
  }, [user]);

  const filtradas = ordens.filter((o) => {
    if (!busca) return true;
    const alvo = `${o.numero} ${o.clientes?.nome || ""} ${o.veiculos?.placa || ""}`.toLowerCase();
    return alvo.includes(busca.toLowerCase());
  });

  return (
    <div>
      <div className="flex items-center justify-between flex-wrap gap-3">
        <h1 className="text-2xl font-bold">Ordens de Serviço</h1>
        <Link href="/ordens/novo" className="btn-primary">+ Nova OS</Link>
      </div>

      <input
        className="input mt-4"
        placeholder="Buscar por número, cliente ou placa..."
        value={busca}
        onChange={(e) => setBusca(e.target.value)}
      />

      <div className="mt-5 space-y-3">
        {loading && <p className="text-gray-500">Carregando...</p>}
        {!loading && filtradas.length === 0 && <p className="text-gray-500">Nenhuma ordem de serviço encontrada.</p>}
        {filtradas.map((o) => (
          <Link key={o.id} href={`/ordens/${o.id}`} className="card flex items-center justify-between gap-4 hover:bg-gray-50">
            <div className="min-w-0">
              <p className="font-semibold">OS #{o.numero} — {o.clientes?.nome}</p>
              <p className="text-sm text-gray-500 truncate">{o.veiculos?.modelo} • {o.veiculos?.placa} • {formatDate(o.created_at)}</p>
            </div>
            <div className="text-right shrink-0">
              <span className={`text-xs px-2 py-1 rounded-full ${STATUS_OS[o.status]?.color}`}>{STATUS_OS[o.status]?.label}</span>
              <p className="font-bold mt-1">{formatMoney(o.valor_total)}</p>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
