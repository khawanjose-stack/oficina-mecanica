import { Suspense } from "react";
import VeiculoForm from "@/components/VeiculoForm";

export default function NovoVeiculoPage() {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-5">Novo Veículo</h1>
      <Suspense>
        <VeiculoForm />
      </Suspense>
    </div>
  );
}
