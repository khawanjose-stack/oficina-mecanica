"use client";

import { useEffect, useState, Suspense } from "react";
import Link from "next/link";
import { useParams } from "next/navigation";
import { supabase } from "@/lib/supabaseClient";
import VeiculoForm from "@/components/VeiculoForm";
import { formatMoney, formatDate, STATUS_ORCAMENTO, STATUS_OS } from "@/lib/format";

export default function VeiculoDetalhePage() {
  const { id } = useParams();
  const [veiculo, setVeiculo] = useState(null);
  const [orcamentos, setOrcamentos] = useState([]);
  const [ordens, setOrdens] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function carregar() {
      const [veiculoRes, orcamentosRes, ordensRes] = await Promise.all([
        supabase.from("veiculos").select("*").eq("id", id).single(),
        supabase.from("orcamentos").select("*").eq("veiculo_id", id).order("created_at", { ascending: false }),
        supabase.from("ordens_servico").select("*").eq("veiculo_id", id).order("created_at", { ascending: false }),
      ]);
      setVeiculo(veiculoRes.data);
      setOrcamentos(orcamentosRes.data || []);
      setOrdens(ordensRes.data || []);
      setLoading(false);
    }
    if (id) carregar();
  }, [id]);

  if (loading) return <p className="text-gray-500">Carregando...</p>;
  if (!veiculo) return <p className="text-gray-500">Veículo não encontrado.</p>;

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold mb-5">Editar Veículo</h1>
        <Suspense>
          <VeiculoForm veiculo={veiculo} />
        </Suspense>
      </div>

      <div>
        <h2 className="font-semibold text-lg mb-3">Histórico de orçamentos</h2>
        {orcamentos.length === 0 && <p className="text-gray-500 text-sm">Nenhum orçamento ainda.</p>}
        <div className="space-y-2">
          {orcamentos.map((o) => (
            <Link key={o.id} href={`/orcamentos/${o.id}`} className="card flex items-center justify-between hover:bg-gray-50">
              <span>Orçamento #{o.numero} — {formatDate(o.created_at)}</span>
              <span className="flex items-center gap-3">
                <span className={`text-xs px-2 py-1 rounded-full ${STATUS_ORCAMENTO[o.status]?.color}`}>{STATUS_ORCAMENTO[o.status]?.label}</span>
                <span className="font-semibold">{formatMoney(o.valor_total)}</span>
              </span>
            </Link>
          ))}
        </div>
      </div>

      <div>
        <h2 className="font-semibold text-lg mb-3">Histórico de ordens de serviço</h2>
        {ordens.length === 0 && <p className="text-gray-500 text-sm">Nenhuma OS ainda.</p>}
        <div className="space-y-2">
          {ordens.map((o) => (
            <Link key={o.id} href={`/ordens/${o.id}`} className="card flex items-center justify-between hover:bg-gray-50">
              <span>OS #{o.numero} — {formatDate(o.created_at)}</span>
              <span className="flex items-center gap-3">
                <span className={`text-xs px-2 py-1 rounded-full ${STATUS_OS[o.status]?.color}`}>{STATUS_OS[o.status]?.label}</span>
                <span className="font-semibold">{formatMoney(o.valor_total)}</span>
              </span>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
