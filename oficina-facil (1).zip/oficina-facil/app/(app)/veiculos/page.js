"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useAuth } from "@/lib/AuthContext";
import { supabase } from "@/lib/supabaseClient";
import toast from "react-hot-toast";

export default function VeiculosPage() {
  const { user } = useAuth();
  const [veiculos, setVeiculos] = useState([]);
  const [busca, setBusca] = useState("");
  const [loading, setLoading] = useState(true);

  async function carregar() {
    if (!user) return;
    setLoading(true);
    let query = supabase
      .from("veiculos")
      .select("*, clientes(nome)")
      .eq("oficina_id", user.id)
      .order("created_at", { ascending: false });
    if (busca) {
      query = query.or(`placa.ilike.%${busca}%,modelo.ilike.%${busca}%,marca.ilike.%${busca}%`);
    }
    const { data, error } = await query;
    if (error) toast.error("Erro ao carregar veículos.");
    setVeiculos(data || []);
    setLoading(false);
  }

  useEffect(() => {
    carregar();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  async function handleExcluir(id) {
    if (!confirm("Excluir este veículo?")) return;
    const { error } = await supabase.from("veiculos").delete().eq("id", id);
    if (error) {
      toast.error("Não foi possível excluir (verifique orçamentos/OS vinculados).");
      return;
    }
    toast.success("Veículo excluído.");
    carregar();
  }

  return (
    <div>
      <div className="flex items-center justify-between flex-wrap gap-3">
        <h1 className="text-2xl font-bold">Veículos</h1>
        <Link href="/veiculos/novo" className="btn-primary">+ Novo Veículo</Link>
      </div>

      <form onSubmit={(e) => { e.preventDefault(); carregar(); }} className="mt-4 flex gap-2">
        <input className="input" placeholder="Buscar por placa, marca ou modelo..." value={busca} onChange={(e) => setBusca(e.target.value)} />
        <button className="btn-secondary shrink-0">Buscar</button>
      </form>

      <div className="mt-5 space-y-3">
        {loading && <p className="text-gray-500">Carregando...</p>}
        {!loading && veiculos.length === 0 && <p className="text-gray-500">Nenhum veículo cadastrado ainda.</p>}
        {veiculos.map((v) => (
          <div key={v.id} className="card flex items-center justify-between gap-4">
            <div className="min-w-0">
              <Link href={`/veiculos/${v.id}`} className="font-semibold text-gray-900 hover:underline block truncate">
                {v.marca} {v.modelo} {v.ano ? `(${v.ano})` : ""}
              </Link>
              <p className="text-sm text-gray-500 truncate">{v.placa} • {v.clientes?.nome}</p>
            </div>
            <div className="flex gap-2 shrink-0">
              <Link href={`/veiculos/${v.id}`} className="btn-secondary text-xs px-3 py-2">Editar</Link>
              <button onClick={() => handleExcluir(v.id)} className="btn-danger text-xs px-3 py-2">Excluir</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
