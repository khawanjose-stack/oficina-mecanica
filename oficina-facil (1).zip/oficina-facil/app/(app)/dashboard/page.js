"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useAuth } from "@/lib/AuthContext";
import { supabase } from "@/lib/supabaseClient";
import { formatMoney } from "@/lib/format";

export default function DashboardPage() {
  const { user, oficina } = useAuth();
  const [stats, setStats] = useState({
    clientes: 0,
    veiculos: 0,
    orcamentosPendentes: 0,
    osAbertas: 0,
    valorRecebido: 0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    async function loadStats() {
      const [clientesRes, veiculosRes, orcamentosRes, osRes, osRecebidoRes] = await Promise.all([
        supabase.from("clientes").select("id", { count: "exact", head: true }).eq("oficina_id", user.id),
        supabase.from("veiculos").select("id", { count: "exact", head: true }).eq("oficina_id", user.id),
        supabase.from("orcamentos").select("id", { count: "exact", head: true }).eq("oficina_id", user.id).eq("status", "pendente"),
        supabase.from("ordens_servico").select("id", { count: "exact", head: true }).eq("oficina_id", user.id).in("status", ["aberta", "em_andamento", "aguardando_aprovacao"]),
        supabase.from("ordens_servico").select("valor_total").eq("oficina_id", user.id).eq("status", "entregue"),
      ]);

      const valorRecebido = (osRecebidoRes.data || []).reduce((acc, r) => acc + Number(r.valor_total || 0), 0);

      setStats({
        clientes: clientesRes.count || 0,
        veiculos: veiculosRes.count || 0,
        orcamentosPendentes: orcamentosRes.count || 0,
        osAbertas: osRes.count || 0,
        valorRecebido,
      });
      setLoading(false);
    }
    loadStats();
  }, [user]);

  const cards = [
    { label: "Clientes", value: stats.clientes },
    { label: "Veículos", value: stats.veiculos },
    { label: "Orçamentos pendentes", value: stats.orcamentosPendentes },
    { label: "Ordens de serviço abertas", value: stats.osAbertas },
    { label: "Valor recebido (OS entregues)", value: formatMoney(stats.valorRecebido), full: true },
  ];

  return (
    <div>
      <h1 className="text-2xl font-bold">Olá, {oficina?.nome_oficina || "bem-vindo(a)"} 👋</h1>
      <p className="text-gray-500 mt-1">Aqui está um resumo da sua oficina hoje.</p>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-6">
        {cards.map((c) => (
          <div key={c.label} className={`card ${c.full ? "col-span-2 sm:col-span-4" : ""}`}>
            <p className="text-xs text-gray-500">{c.label}</p>
            <p className="text-2xl font-bold mt-1">{loading ? "…" : c.value}</p>
          </div>
        ))}
      </div>

      <div className="mt-8">
        <h2 className="font-semibold text-gray-700 mb-3">Ações rápidas</h2>
        <div className="grid sm:grid-cols-3 gap-3">
          <Link href="/clientes/novo" className="btn-primary justify-center">+ Novo Cliente</Link>
          <Link href="/orcamentos/novo" className="btn-primary justify-center">+ Novo Orçamento</Link>
          <Link href="/ordens/novo" className="btn-primary justify-center">+ Nova Ordem de Serviço</Link>
        </div>
      </div>
    </div>
  );
}
