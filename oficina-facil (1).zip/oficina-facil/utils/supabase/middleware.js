import { createServerClient } from "@supabase/ssr";
import { NextResponse } from "next/server";

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY;

const ROTAS_PROTEGIDAS = ["/dashboard", "/clientes", "/veiculos", "/orcamentos", "/ordens"];
const ROTAS_AUTH = ["/login", "/cadastro"];

export async function updateSession(request) {
  let supabaseResponse = NextResponse.next({
    request,
  });

  const supabase = createServerClient(supabaseUrl, supabaseKey, {
    cookies: {
      getAll() {
        return request.cookies.getAll();
      },
      setAll(cookiesToSet) {
        cookiesToSet.forEach(({ name, value }) => request.cookies.set(name, value));
        supabaseResponse = NextResponse.next({ request });
        cookiesToSet.forEach(({ name, value, options }) =>
          supabaseResponse.cookies.set(name, value, options)
        );
      },
    },
  });

  // IMPORTANTE: não colocar nenhuma lógica entre createServerClient() e
  // supabase.auth.getUser() — isso pode causar desconexões aleatórias.
  const {
    data: { user },
  } = await supabase.auth.getUser();

  const path = request.nextUrl.pathname;
  const emRotaProtegida = ROTAS_PROTEGIDAS.some((r) => path.startsWith(r));
  const emRotaAuth = ROTAS_AUTH.includes(path);

  // Sem sessão tentando acessar área logada → manda pro login
  if (!user && emRotaProtegida) {
    const url = request.nextUrl.clone();
    url.pathname = "/login";
    return NextResponse.redirect(url);
  }

  // Já logado tentando ver login/cadastro → manda pro dashboard
  if (user && emRotaAuth) {
    const url = request.nextUrl.clone();
    url.pathname = "/dashboard";
    return NextResponse.redirect(url);
  }

  return supabaseResponse;
}
